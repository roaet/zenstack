
#ifndef __ASM_XEN_DRIVER_UTIL_H__
#define __ASM_XEN_DRIVER_UTIL_H__

#include <linux/vmalloc.h>
#include <linux/device.h>

extern struct class *get_xen_class(void);

#endif /* __ASM_XEN_DRIVER_UTIL_H__ */
