/* include/version.h */
#define CONFIG_SND_VERSION "1.0.21"
#define CONFIG_SND_DATE ""
